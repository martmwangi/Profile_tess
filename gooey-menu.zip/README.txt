A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/ZQmZdz.

 Gooey menu with CSS and SVG filters. Version 1

Forked from [Lucas Bebber](http://codepen.io/lbebber/)'s Pen [Gooey Menu](http://codepen.io/lbebber/pen/LELBEo/).